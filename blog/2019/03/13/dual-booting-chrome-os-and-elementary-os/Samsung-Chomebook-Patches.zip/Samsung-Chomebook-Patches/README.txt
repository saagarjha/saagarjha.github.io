# Recompile your kernel with Fix-support-for-Samsung-Series-5-Chromebook.patch
# applied to it, then run the following commands:

# Audio
sudo apt-get install alsa-base
sudo cp asound.state /var/lib/alsa/asound.state
sudo alsa force-reload

# Backlight (make xbacklight work. Usage: "xbacklight -set PERCENTAGE")
# ex: "xbacklight -set 50"
sudo cp xorg.conf /etc/X11